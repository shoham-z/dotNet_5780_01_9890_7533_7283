﻿using System;

using System.Text;



class RandomNumberSample

{

    static void Main(string[] args)

    {
        int[] A = new int[20];
        int[] B = new int[20];
        int[] C = new int[20];
        RandomGenerator generator = new RandomGenerator();

        for (int i = 0; i < 20; i++)
        {
            A[i] = generator.RandomNumber(18, 122);
            B[i] = generator.RandomNumber(18, 122);
        }
        for (int i = 0; i < 20; i++)
        {
            C[i] = Math.Abs(A[i] - B[i]);
        }
        for (int i = 0; i < 20; i++)
        {
            Console.Write(A[i]+"\t");
        }
        Console.WriteLine();
        for (int i = 0; i < 20; i++)
        {
            Console.Write(B[i]+"\t");
        }
        Console.WriteLine();
        for (int i = 0; i < 20; i++)
        {
            Console.Write(C[i]+"\t");

        }
        Console.WriteLine();
        Console.ReadKey();
    }
}



public class RandomGenerator

{
    public int RandomNumber(int min, int max)

    {

        Random random = new Random();

        return random.Next(min, max);

    }
}